<?php

require '8021x_util.php';

$auth_challenge = '1c0b191aa7156ea26eebd14a7d0210b7';
$peer_challenge = 'ecd376e26de9421e7619f4e553d947fd';
$username = '3135303132333435363738';
$password = 'hiwifi';

// （1） 把从http请求中获取的参数 (auth_challenge, peer_challenge, username) 做二进制化处理，方便下一个阶段计算nt_reponse, auth_response
$auth_challenge = pack ( 'H*', $auth_challenge );
$peer_challenge = pack ( 'H*', $peer_challenge );
$username = hex2bin ( $username );

// (2) 从服务端获取密码，注意密码在服务端是用明文保存
$password = 'hiwifi';

// （3） 调用函数，得到结果数组。
$ret = GenerateJSONAllResponse ( $auth_challenge, $peer_challenge, $username, $password );

$response = array(
    "nt_response" => "9fdc658a853b13deff007b30867dee4ee4151265cac14660",
    "auth_response"=> "7aec24da6777a5b7b4505ba3f45ffb57744c2622",
    "master_key"=> "a75cc3743dda3b5c38b621793e64a43f",
    "add_mac_to_set"=> true
);

echo "预期正确的response:\n";
var_dump($response);
echo "生成的response:\n";
var_dump($ret);
